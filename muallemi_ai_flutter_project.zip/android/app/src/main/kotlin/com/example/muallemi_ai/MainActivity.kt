package com.example.muallemi_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
