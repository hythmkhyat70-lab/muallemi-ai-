import 'package:flutter/material.dart';

void main() {
  runApp(const MuallemiApp());
}

class MuallemiApp extends StatelessWidget {
  const MuallemiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Muallemi AI',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: const ChildHomePage(),
    );
  }
}

class ChildHomePage extends StatelessWidget {
  const ChildHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('معلّمي AI'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    const CircleAvatar(
                      radius: 38,
                      child: Icon(Icons.school, size: 42),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'مرحباً يا بطل! 👋',
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'جاهز لدرس اليوم؟',
                      style: TextStyle(
                        fontSize: 17,
                        color: Colors.grey.shade700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'درس اليوم',
              textAlign: TextAlign.right,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Card(
              child: ListTile(
                leading: const CircleAvatar(
                  child: Icon(Icons.palette),
                ),
                title: const Text(
                  'Renkler - الألوان',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: const Text('اللغة التركية • الصف الأول'),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const LessonPage(),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const ParentPage(),
                  ),
                );
              },
              icon: const Icon(Icons.family_restroom),
              label: const Text('لوحة ولي الأمر'),
            ),
          ],
        ),
      ),
    );
  }
}

class LessonPage extends StatefulWidget {
  const LessonPage({super.key});

  @override
  State<LessonPage> createState() => _LessonPageState();
}

class _LessonPageState extends State<LessonPage> {
  final words = const [
    ('Kırmızı', 'أحمر'),
    ('Mavi', 'أزرق'),
    ('Sarı', 'أصفر'),
  ];

  int index = 0;
  int score = 0;

  void answer(bool correct) {
    if (correct) score++;
    if (index < words.length - 1) {
      setState(() => index++);
    } else {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('أحسنت! 🎉'),
          content: Text('أنهيت الدرس بنتيجة $score / ${words.length}'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context);
              },
              child: const Text('إنهاء'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final word = words[index];
    return Scaffold(
      appBar: AppBar(title: const Text('درس الألوان')),
      body: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            LinearProgressIndicator(
              value: (index + 1) / words.length,
            ),
            const SizedBox(height: 35),
            const Text(
              'ما معنى هذه الكلمة؟',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(35),
                child: Text(
                  word.$1,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 42,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 25),
            FilledButton(
              onPressed: () => answer(true),
              child: Text(word.$2),
            ),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: () => answer(false),
              child: const Text('إجابة أخرى'),
            ),
            const Spacer(),
            Text(
              'السؤال ${index + 1} من ${words.length}',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

class ParentPage extends StatelessWidget {
  const ParentPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة ولي الأمر')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: const [
          Card(
            child: ListTile(
              leading: Icon(Icons.person),
              title: Text('الطفل'),
              subtitle: Text('الصف الأول'),
            ),
          ),
          Card(
            child: ListTile(
              leading: Icon(Icons.language),
              title: Text('اللغة الحالية'),
              subtitle: Text('التركية'),
            ),
          ),
          Card(
            child: ListTile(
              leading: Icon(Icons.trending_up),
              title: Text('التقدم'),
              subtitle: Text('يتم تحديث التقدم بعد كل درس'),
            ),
          ),
          Card(
            child: ListTile(
              leading: Icon(Icons.schedule),
              title: Text('الجدول اليومي'),
              subtitle: Text('30 دقيقة يومياً'),
            ),
          ),
        ],
      ),
    );
  }
}
